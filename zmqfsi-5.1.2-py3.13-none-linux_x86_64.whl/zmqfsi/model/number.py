#!/usr/bin/python
# -*- coding: utf-8 -*-
# cython: language_level=3

"""
@author: zmate  
@file: order_status.py  
@time: 2019/7/5 下午6:18
"""


"""
负0(负的百亿分之一), 正0(百亿分之一)
"""

NEGATIVE_ZERO = -0.0000000001
POSITIVE_ZERO = 0.0000000001
