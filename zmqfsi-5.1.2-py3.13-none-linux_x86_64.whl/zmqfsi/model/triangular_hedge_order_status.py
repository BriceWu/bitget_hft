#!/usr/bin/python
# -*- coding: utf-8 -*-
# cython: language_level=3

"""
@author: zmate  
@file: triangular_hedge_order_status.py  
@time: 2019/7/23 下午3:13
"""
from enum import Enum


class TriangularHedgeOrderStatus(Enum):
    """
    无需对冲, 未对冲, b边未对冲, b边对冲中, b边对冲成功, c边未对冲, c边对冲中, c边对冲成功, 对冲成功
    """
    HEDGE_NO_NEED = 'hedge_no_need'
    UNHEDGE = 'unhedge'
    UNHEDGE_B_SIDE = 'unhedge_b_side'
    HEDGING_PEND_B_SIDE = 'hedging_pend_b_side'
    HEDGE_B_SIDE = 'hedge_b_side'
    HEDGING_PEND_C_SIDE = 'hedging_pend_c_side'
    UNHEDGE_C_SIDE = 'unhedge_c_side'
    HEDGE_C_SIDE = 'hedge_c_side'
    HEDGE = 'hedge'
