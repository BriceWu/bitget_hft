#!/usr/bin/python
# -*- coding: utf-8 -*-
# cython: language_level=3
"""
@author: bricewu  
@file: trade_side_status.py
@time: 2020/3/2 下午4:04
"""
from enum import Enum


class TradeSideStatus(Enum):
    """
    买, 卖, 买卖都, 买卖都不
    """
    SELL_BUY_NEITHER = 0
    ONLY_BUY = 1
    ONLY_SELL = 2
    SELL_BUY_BOTH = 3
