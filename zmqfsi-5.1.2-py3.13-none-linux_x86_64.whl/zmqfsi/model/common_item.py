#!/usr/bin/python
# -*- coding: utf-8 -*-
# cython: language_level=3

"""
@author: zmate  
@file: common fields.py
@time: 2021/1/9 下午9:48
"""

STATUS = 'status'
_ID = '_id'
ORDER_INFO = 'order_info'
PRICE = 'price'
VOL = 'vol'
AMOUNT = 'amount'
SIDE = 'side'
MSG = 'msg'
TIME = 'time'
ORDER_PARAMS = 'order_params'
HEDGING_ORDER_ID = 'hedging_order_id'
HEDGING_TIME = 'hedging_time'
UPDATE_TIME = 'update_time'

P_PRICE = 'p_price'
P_VOL = 'p_vol'
P_SIDE = 'p_side'
POST_ONLY = 'post_only'
P_ORDER_ID = 'p_order_id'
P_CLIENT_ID = 'p_client_id'
SELL = 'sell'
BUY = 'buy'
SYMBOL = 'symbol'
TIMESTAMP = 'timestamp'

ASKS = 'asks'
BIDS = 'bids'
ACCOUNT = 'account'
POSITION = 'position'
EQUITY = 'equity'

# p:price, v:vol, s:side, o:order_id, c:client_order_id, t:type
ORDER_PRICE = 'p'
ORDER_VOL = 'v'
ORDER_SIDE = 's'  # 买, 卖, 开多, 开空, 平多, 平空
ORDER_ID = 'i'  # 服务器返回的订单id
CLIENT_ORDER_ID = 'c'  # client order id, 客户端创建的order id
ORDER_TYPE = 't'  # 订单类型, 市价限价
ASKS_ORDERS = 'a'  # asks
BIDS_ORDERS = 'b'  # bids

