#!/usr/bin/python
# -*- coding: utf-8 -*-
# cython: language_level=3

"""
@author: zmate  
@file: triangular_hedge_order_status.py  
@time: 2019/7/23 下午3:13
"""
from enum import Enum


class HedgeOrderStatus(Enum):
    """
    无需对冲, 未对冲, 预对冲, 对冲中, 对冲成功, 自对冲成功, 预止损，对冲止损中, 对冲止损
    """
    HEDGE_NO_NEED = 'hedge_no_need'
    UNHEDGE = 'unhedge'
    PRE_HEDGE = 'pre_hedge'
    HEDGING_PEND = 'hedging_pend'
    HEDGE = 'hedge'
    HEDGE_SELF = 'hedge_self'

    PRE_STOP_LOSS = 'pre_stop_loss'
    HEDGING_PEND_STOP_LOSS = 'hedging_pend_stop_loss'
    HEDGE_STOP_LOSS = 'hedge_stop_loss'
