#!/usr/bin/python
# -*- coding: utf-8 -*-
# cython: language_level=3

class Account:
    def __init__(self, zm_account=None, access_key=None, secret_key=None, user_id=None, pass_phrase=None):
        """
        账户
        :param zm_account: 账号
        :param access_key: 公钥
        :param secret_key: 私钥
        :param user_id: 用户id
        :param pass_phrase: 密码短语
        """
        self._zm_account = zm_account
        self._access_key = access_key
        self._secret_key = secret_key
        self._user_id = user_id
        self._pass_phrase = pass_phrase