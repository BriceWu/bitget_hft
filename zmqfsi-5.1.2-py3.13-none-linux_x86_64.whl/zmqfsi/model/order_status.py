#!/usr/bin/python
# -*- coding: utf-8 -*-
# cython: language_level=3

"""
@author: zmate  
@file: order_status.py  
@time: 2019/7/5 下午6:18
"""
from enum import Enum


class OrderStatus(Enum):
    """
    -1:订单已撤销或不存在, 0:无法查询到订单详情, 1:订单未成交, 2:订单部分成交, 3:订单部分成交撤销, 4:订单全部成交
    """
    CANCELED = -1
    UNKNOWN = 0
    NEW = 1
    PARTIALLY_FILLED = 2
    PARTIALLY_CANCELED = 3
    FILLED = 4

