#!/usr/bin/python
# -*- coding: utf-8 -*-
# cython: language_level=3

class HttpMultiModel:
    def __init__(self, client=None, request_time=None, request_id=None):
        """
        账户
        :param client: http/https客户端
        :param request_time: 请求时间
        :param request_id: 请求id
        """
        self.client = client
        self.request_time = request_time
        self.request_id = request_id
